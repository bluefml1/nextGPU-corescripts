# Add Steam Games with Icons + Kiosk Mode + Desktop App
$AppsFile = "C:\Program Files\Sunshine\config\apps.json"
$SteamPath = "${env:ProgramFiles(x86)}\Steam"

# Create config dir if missing
$ConfigDir = "C:\Program Files\Sunshine\config"
if (!(Test-Path $ConfigDir)) { 
    New-Item -ItemType Directory -Path $ConfigDir -Force | Out-Null 
}

# Load or initialize config
if (Test-Path $AppsFile) {
    $Config = Get-Content $AppsFile -Raw | ConvertFrom-Json
} else {
    $Config = [PSCustomObject]@{
        env = @{};
        apps = @()
    }
}

# Ensure apps is an array
if ($Config.apps -isnot [System.Array]) { 
    $Config.apps = @($Config.apps) 
}

# === ADD OR UPDATE DESKTOP APP FIRST ===
$DesktopExists = $Config.apps | Where-Object { $_.name -eq "Desktop" }

$DesktopApp = [PSCustomObject]@{
    "auto-detach"             = $true
    "elevated"                = $false
    "exclude-global-prep-cmd" = $false
    "exit-timeout"            = 5
    "image-path"              = "desktop.png"
    "name"                    = "Desktop"
    "prep-cmd"                = @(
        [PSCustomObject]@{
            do       = 'curl -k -X POST https://localhost:47990/api/hide-cursor -H "Content-Type: application/json" -d {}'
            elevated = $false
            undo     = 'curl -k -X POST https://localhost:47990/api/show-cursor -H "Content-Type: application/json" -d {}'
        }
    )
    "wait-all"                = $true
}

if ($DesktopExists) {
    # Update existing Desktop app
    $index = $Config.apps.IndexOf($DesktopExists)
    $Config.apps[$index] = $DesktopApp
    Write-Host "🔄 Updated: Desktop app (added prep-cmd)"
} else {
    # Add new Desktop app at the beginning
    $Config.apps = @($DesktopApp) + $Config.apps
    Write-Host "➕ Added: Desktop app"
}

# Get all Steam libraries
$Libraries = @($SteamPath)
$LibraryFile = "$SteamPath\steamapps\libraryfolders.vdf"
if (Test-Path $LibraryFile) {
    $content = Get-Content $LibraryFile -ErrorAction SilentlyContinue
    foreach ($line in $content) {
        if ($line -match '\"(\d+)\"\s+\"(.+?)\"') {
            $path = $matches[2] -replace '\\\\', '\'
            if (Test-Path "$path\steamapps") {
                $Libraries += $path
            }
        }
    }
}

$AddedCount = 0
foreach ($lib in $Libraries) {
    $manifests = Get-ChildItem -Path "$lib\steamapps" -Filter "appmanifest_*.acf" -ErrorAction SilentlyContinue
    foreach ($mf in $manifests) {
        $appID = ($mf.BaseName -replace 'appmanifest_')
        $name = $null
        foreach ($line in (Get-Content $mf.FullName -ErrorAction SilentlyContinue)) {
            if ($line -match '\"name\"\s+\"(.+?)\"') {
                $name = $matches[1]
                break
            }
        }

        if ($name -and $name -notmatch 'DLC|Soundtrack|Demo|^Steam.*') {
            $Exists = $Config.apps | Where-Object { $_.name -eq $name }
            if (-not $Exists) {

                # Get icon path
                $IconPath = ""
                $PossibleIcon = "$SteamPath\appcache\librarycache\$appID\logo.jpg"
                if (Test-Path $PossibleIcon) {
                    $IconPath = $PossibleIcon
                } else {
                    $PossibleIcon = "$SteamPath\appcache\librarycache\$appID\logo.png"
                    if (Test-Path $PossibleIcon) {
                        $IconPath = $PossibleIcon
                    }
                }

                # === EXACT FORMAT YOU WANT ===
                $NewApp = [PSCustomObject]@{
                    name                          = "$name"
                    cmd                           = "steam://rungameid/$appID"
                    output                        = "$($name -replace '[^a-zA-Z0-9 _]', '_').kiosk.log".ToLower()
                    "prep-cmd"                    = @(
                        [PSCustomObject]@{
                            do        = ""
                            undo      = '"C:\Program Files\Sunshine\scripts\disable_kiosk_game.bat"'
                            elevated  = $true
                        }
                    )
                    detached                      = @('powershell -WindowStyle Hidden -Command "& ''C:\Program Files\Sunshine\scripts\enable_kiosk_game.bat''"')
                    "auto-detach"                 = $true
                    "exclude-global-prep-cmd"     = $false
                    "exit-timeout"                = 30
                    "image-path"                  = $IconPath
                    "elevated"                    = $true
                    "wait-all"                    = $false
                    "wait-exit"                   = $false
                }

                $Config.apps += $NewApp
                $AddedCount++

                $iconStatus = if ($IconPath) { '✅' } else { '❌' }
                Write-Host "➕ Added: $name (Icon: $iconStatus)"
            }
        }
    }
}

# Save JSON without BOM (Sunshine compatible)
$JsonContent = $Config | ConvertTo-Json -Depth 10
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllLines($AppsFile, $JsonContent, $Utf8NoBom)

Write-Host "`n✅ Done. Added Desktop app + $AddedCount game(s) to $AppsFile"
Write-Host "⚠️  Restart Sunshine for changes to take effect."